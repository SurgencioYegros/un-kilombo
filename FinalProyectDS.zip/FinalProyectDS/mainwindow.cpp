#include "mainwindow.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QFont>
#include <QMessageBox>
#include <random>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), user1Score(0), user2Score(0), currentRound(1)
{
    srand(time(0));
    setupUI();
    setWindowTitle("Hangman Game");
    resize(800, 600);
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);

    setupSetupPage();
    setupWordInputPage();
    setupGamePage();
    setupEndPage();

    stackedWidget->setCurrentWidget(setupPage);
}

void MainWindow::setupSetupPage()
{
    setupPage = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(setupPage);

    QLabel *titleLabel = new QLabel("HANGMAN GAME");
    QFont titleFont;
    titleFont.setPointSize(24);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);

    QGroupBox *playersGroup = new QGroupBox("Players");
    QVBoxLayout *playersLayout = new QVBoxLayout(playersGroup);

    QLabel *user1Label = new QLabel("User 1 Name:");
    user1Edit = new QLineEdit();
    user1Edit->setPlaceholderText("Enter name for User 1");

    QLabel *user2Label = new QLabel("User 2 Name:");
    user2Edit = new QLineEdit();
    user2Edit->setPlaceholderText("Enter name for User 2");

    startButton = new QPushButton("Start Game");
    startButton->setMinimumHeight(40);

    playersLayout->addWidget(user1Label);
    playersLayout->addWidget(user1Edit);
    playersLayout->addWidget(user2Label);
    playersLayout->addWidget(user2Edit);

    layout->addWidget(titleLabel);
    layout->addWidget(playersGroup);
    layout->addWidget(startButton);
    layout->addStretch();

    connect(startButton, &QPushButton::clicked, this, &MainWindow::startGame);

    stackedWidget->addWidget(setupPage);
}

void MainWindow::setupWordInputPage()
{
    wordInputPage = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(wordInputPage);

    currentPlayerLabel = new QLabel();
    QFont playerFont;
    playerFont.setPointSize(16);
    playerFont.setBold(true);
    currentPlayerLabel->setFont(playerFont);
    currentPlayerLabel->setAlignment(Qt::AlignCenter);

    wordInputInstructions = new QLabel("Please enter a secret word and number of lives:");
    wordInputInstructions->setAlignment(Qt::AlignCenter);

    QGroupBox *wordGroup = new QGroupBox("Word Setup");
    QVBoxLayout *wordLayout = new QVBoxLayout(wordGroup);

    QLabel *wordLabel = new QLabel("Secret Word:");
    secretWordEdit = new QLineEdit();
    secretWordEdit->setPlaceholderText("Enter secret word");
    secretWordEdit->setEchoMode(QLineEdit::Password);

    QLabel *livesLabel = new QLabel("Number of Lives (1-6):");
    livesSpinBox = new QSpinBox();
    livesSpinBox->setRange(1, 6);
    livesSpinBox->setValue(6);

    submitWordButton = new QPushButton("Submit Word");
    submitWordButton->setMinimumHeight(40);

    wordLayout->addWidget(wordLabel);
    wordLayout->addWidget(secretWordEdit);
    wordLayout->addWidget(livesLabel);
    wordLayout->addWidget(livesSpinBox);

    layout->addWidget(currentPlayerLabel);
    layout->addWidget(wordInputInstructions);
    layout->addWidget(wordGroup);
    layout->addWidget(submitWordButton);
    layout->addStretch();

    connect(submitWordButton, &QPushButton::clicked, this, &MainWindow::submitWord);

    stackedWidget->addWidget(wordInputPage);
}

void MainWindow::setupGamePage()
{
    gamePage = new QWidget();
    QHBoxLayout *mainLayout = new QHBoxLayout(gamePage);

    // Left side - Hangman display
    QVBoxLayout *leftLayout = new QVBoxLayout();
    hangmanDisplay = new QLabel();
    QFont monospaceFont("Courier New", 12);
    hangmanDisplay->setFont(monospaceFont);
    hangmanDisplay->setAlignment(Qt::AlignCenter);
    hangmanDisplay->setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc; padding: 10px;");
    hangmanDisplay->setMinimumSize(300, 200);

    leftLayout->addWidget(new QLabel("Hangman:"));
    leftLayout->addWidget(hangmanDisplay);
    leftLayout->addStretch();

    // Right side - Game controls
    QVBoxLayout *rightLayout = new QVBoxLayout();

    currentGuesserLabel = new QLabel();
    QFont guesserFont;
    guesserFont.setPointSize(14);
    guesserFont.setBold(true);
    currentGuesserLabel->setFont(guesserFont);

    livesLabel = new QLabel();
    wordProgressLabel = new QLabel();
    QFont progressFont;
    progressFont.setPointSize(16);
    progressFont.setFamily("Courier New");
    wordProgressLabel->setFont(progressFont);

    usedLettersLabel = new QLabel("Used letters: ");

    QGroupBox *guessGroup = new QGroupBox("Make a Guess");
    QVBoxLayout *guessLayout = new QVBoxLayout(guessGroup);

    QHBoxLayout *letterLayout = new QHBoxLayout();
    letterGuessEdit = new QLineEdit();
    letterGuessEdit->setPlaceholderText("Enter a letter");
    letterGuessEdit->setMaxLength(1);
    guessLetterButton = new QPushButton("Guess Letter");
    letterLayout->addWidget(letterGuessEdit);
    letterLayout->addWidget(guessLetterButton);

    QHBoxLayout *wordLayout = new QHBoxLayout();
    wordGuessEdit = new QLineEdit();
    wordGuessEdit->setPlaceholderText("Enter the full word");
    guessWordButton = new QPushButton("Guess Word");
    wordLayout->addWidget(wordGuessEdit);
    wordLayout->addWidget(guessWordButton);

    guessLayout->addLayout(letterLayout);
    guessLayout->addLayout(wordLayout);

    rightLayout->addWidget(currentGuesserLabel);
    rightLayout->addWidget(livesLabel);
    rightLayout->addWidget(new QLabel("Word Progress:"));
    rightLayout->addWidget(wordProgressLabel);
    rightLayout->addWidget(usedLettersLabel);
    rightLayout->addWidget(guessGroup);
    rightLayout->addStretch();

    mainLayout->addLayout(leftLayout);
    mainLayout->addLayout(rightLayout);

    connect(guessLetterButton, &QPushButton::clicked, this, &MainWindow::guessLetter);
    connect(guessWordButton, &QPushButton::clicked, this, &MainWindow::guessWord);
    connect(letterGuessEdit, &QLineEdit::returnPressed, this, &MainWindow::guessLetter);
    connect(wordGuessEdit, &QLineEdit::returnPressed, this, &MainWindow::guessWord);

    stackedWidget->addWidget(gamePage);
}

void MainWindow::setupEndPage()
{
    endPage = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(endPage);

    resultLabel = new QLabel();
    QFont resultFont;
    resultFont.setPointSize(18);
    resultFont.setBold(true);
    resultLabel->setFont(resultFont);
    resultLabel->setAlignment(Qt::AlignCenter);

    scoreLabel = new QLabel();
    QFont scoreFont;
    scoreFont.setPointSize(14);
    scoreLabel->setFont(scoreFont);
    scoreLabel->setAlignment(Qt::AlignCenter);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    playAgainButton = new QPushButton("Play Another Round");
    exitButton = new QPushButton("Exit Game");

    playAgainButton->setMinimumHeight(40);
    exitButton->setMinimumHeight(40);

    buttonLayout->addWidget(playAgainButton);
    buttonLayout->addWidget(exitButton);

    layout->addWidget(resultLabel);
    layout->addWidget(scoreLabel);
    layout->addLayout(buttonLayout);
    layout->addStretch();

    connect(playAgainButton, &QPushButton::clicked, this, &MainWindow::playAgain);
    connect(exitButton, &QPushButton::clicked, this, &MainWindow::exitGame);

    stackedWidget->addWidget(endPage);
}

void MainWindow::startGame()
{
    if (user1Edit->text().isEmpty() || user2Edit->text().isEmpty()) {
        QMessageBox::warning(this, "Warning", "Please enter names for both users.");
        return;
    }

    user1Name = user1Edit->text().toStdString();
    user2Name = user2Edit->text().toStdString();
    user1Score = 0;
    user2Score = 0;
    currentRound = 1;
    usedWords.clear();

    startNewRound();
}

void MainWindow::startNewRound()
{
    // Determine who chooses and who guesses
    if (currentRound % 2 == 1) {
        currentChooser = user1Name;
        currentGuesser = user2Name;
    } else {
        currentChooser = user2Name;
        currentGuesser = user1Name;
    }

    currentPlayerLabel->setText(QString("Round %1 - %2's turn to choose a word").arg(currentRound).arg(QString::fromStdString(currentChooser)));
    secretWordEdit->clear();
    livesSpinBox->setValue(6);

    stackedWidget->setCurrentWidget(wordInputPage);
}

void MainWindow::submitWord()
{
    if (secretWordEdit->text().isEmpty()) {
        QMessageBox::warning(this, "Warning", "Please enter a secret word.");
        return;
    }

    std::string word = secretWordEdit->text().toStdString();
    toLowerCase(word);

    if (alreadyUsed(word, usedWords)) {
        QMessageBox::warning(this, "Warning", "This word has already been used. Please choose a different word.");
        return;
    }

    currentWord.secretWord = word;
    currentWord.lives = livesSpinBox->value();
    usedWords.push_back(word);

    resetGameState();
    revealRandomLetter();
    updateGameDisplay();

    stackedWidget->setCurrentWidget(gamePage);
}

void MainWindow::resetGameState()
{
    guessedLetters.clear();
    remainingLives = currentWord.lives;
    letterGuessEdit->clear();
    wordGuessEdit->clear();
}

void MainWindow::guessLetter()
{
    if (letterGuessEdit->text().isEmpty()) {
        QMessageBox::warning(this, "Warning", "Please enter a letter.");
        return;
    }

    char guess = tolower(letterGuessEdit->text().toStdString()[0]);

    if (std::find(guessedLetters.begin(), guessedLetters.end(), guess) != guessedLetters.end()) {
        QMessageBox::information(this, "Information", "You already guessed that letter. Try again.");
        letterGuessEdit->clear();
        return;
    }

    guessedLetters.push_back(guess);

    if (currentWord.secretWord.find(guess) != std::string::npos) {
        QMessageBox::information(this, "Correct!", "Correct guess!");
    } else {
        QMessageBox::information(this, "Wrong!", "Wrong guess!");
        remainingLives--;
    }

    letterGuessEdit->clear();
    updateGameDisplay();

    if (isWordGuessed()) {
        endRound(true);
    } else if (remainingLives <= 0) {
        endRound(false);
    }
}

void MainWindow::guessWord()
{
    if (wordGuessEdit->text().isEmpty()) {
        QMessageBox::warning(this, "Warning", "Please enter a word.");
        return;
    }

    std::string guess = wordGuessEdit->text().toStdString();
    toLowerCase(guess);

    if (guess == currentWord.secretWord) {
        endRound(true);
    } else {
        QMessageBox::information(this, "Wrong!", "Incorrect word! You lose one life.");
        remainingLives--;
        wordGuessEdit->clear();
        updateGameDisplay();

        if (remainingLives <= 0) {
            endRound(false);
        }
    }
}

void MainWindow::updateGameDisplay()
{
    currentGuesserLabel->setText(QString("%1's turn to guess").arg(QString::fromStdString(currentGuesser)));
    livesLabel->setText(QString("Lives remaining: %1").arg(remainingLives));

    showProgress();
    showUsedLetters();
    drawHangman(remainingLives, currentWord.lives);
}

void MainWindow::showProgress()
{
    QString progress;
    for (char c : currentWord.secretWord) {
        if (std::find(guessedLetters.begin(), guessedLetters.end(), c) != guessedLetters.end()) {
            progress += QString(c) + " ";
        } else {
            progress += "_ ";
        }
    }
    wordProgressLabel->setText(progress);
}

void MainWindow::showUsedLetters()
{
    QString used = "Used letters: ";
    for (char c : guessedLetters) {
        used += QString(c) + " ";
    }
    usedLettersLabel->setText(used);
}

void MainWindow::drawHangman(int livesLeft, int totalLives)
{
    int stages = 7;
    int state = stages - (livesLeft * stages / totalLives);
    if (state < 0) state = 0;
    if (state > 6) state = 6;

    QString hangman;
    switch(state) {
    case 0:
        hangman = " +---+\n |   |\n     |\n     |\n     |\n     |\n========="; break;
    case 1:
        hangman = " +---+\n |   |\n O   |\n     |\n     |\n     |\n========="; break;
    case 2:
        hangman = " +---+\n |   |\n O   |\n |   |\n     |\n     |\n========="; break;
    case 3:
        hangman = " +---+\n |   |\n O   |\n/|   |\n     |\n     |\n========="; break;
    case 4:
        hangman = " +---+\n |   |\n O   |\n/|\\  |\n     |\n     |\n========="; break;
    case 5:
        hangman = " +---+\n |   |\n O   |\n/|\\  |\n/    |\n     |\n========="; break;
    case 6:
        hangman = " +---+\n |   |\n O   |\n/|\\  |\n/ \\  |\n     |\n========="; break;
    }
    hangmanDisplay->setText(hangman);
}

void MainWindow::endRound(bool guesserWon)
{
    QString message;
    if (guesserWon) {
        message = QString("Congratulations %1! You guessed the word: %2")
        .arg(QString::fromStdString(currentGuesser))
            .arg(QString::fromStdString(currentWord.secretWord));
        if (currentGuesser == user1Name) {
            user1Score++;
        } else {
            user2Score++;
        }
    } else {
        message = QString("Game over! The correct word was: %1\n%2 wins this round!")
        .arg(QString::fromStdString(currentWord.secretWord))
            .arg(QString::fromStdString(currentChooser));
        if (currentChooser == user1Name) {
            user1Score++;
        } else {
            user2Score++;
        }
    }

    resultLabel->setText(message);
    scoreLabel->setText(QString("SCOREBOARD:\n%1: %2 point(s)\n%3: %4 point(s)")
                            .arg(QString::fromStdString(user1Name)).arg(user1Score)
                            .arg(QString::fromStdString(user2Name)).arg(user2Score));

    stackedWidget->setCurrentWidget(endPage);
    currentRound++;
}

void MainWindow::playAgain()
{
    startNewRound();
}

void MainWindow::exitGame()
{
    QString finalMessage;
    if (user1Score > user2Score) {
        finalMessage = QString("%1 wins the game!").arg(QString::fromStdString(user1Name));
    } else if (user2Score > user1Score) {
        finalMessage = QString("%1 wins the game!").arg(QString::fromStdString(user2Name));
    } else {
        finalMessage = "It's a tie!";
    }

    QMessageBox::information(this, "Final Result",
                             QString("FINAL RESULT\n%1: %2 point(s)\n%3: %4 point(s)\n\n%5")
                                 .arg(QString::fromStdString(user1Name)).arg(user1Score)
                                 .arg(QString::fromStdString(user2Name)).arg(user2Score)
                                 .arg(finalMessage));

    QApplication::quit();
}

bool MainWindow::isWordGuessed()
{
    for (char c : currentWord.secretWord) {
        if (std::find(guessedLetters.begin(), guessedLetters.end(), c) == guessedLetters.end()) {
            return false;
        }
    }
    return true;
}

void MainWindow::revealRandomLetter()
{
    if (currentWord.secretWord.empty()) return;

    std::vector<char> unrevealedLetters;
    for (char c : currentWord.secretWord) {
        if (std::find(guessedLetters.begin(), guessedLetters.end(), c) == guessedLetters.end()) {
            if (std::find(unrevealedLetters.begin(), unrevealedLetters.end(), c) == unrevealedLetters.end()) {
                unrevealedLetters.push_back(c);
            }
        }
    }

    if (!unrevealedLetters.empty()) {
        char randomLetter = unrevealedLetters[rand() % unrevealedLetters.size()];
        guessedLetters.push_back(randomLetter);
    }
}

void MainWindow::toLowerCase(std::string &s)
{
    for (size_t i = 0; i < s.length(); ++i) {
        s[i] = tolower(static_cast<unsigned char>(s[i]));
    }
}

bool MainWindow::alreadyUsed(const std::string &word, const std::vector<std::string> &usedWords)
{
    for (const std::string &usedWord : usedWords) {
        if (usedWord == word) {
            return true;
        }
    }
    return false;
}

#include "mainwindow.moc"

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QSpinBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QStackedWidget>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <ctime>

QT_BEGIN_NAMESPACE
class QVBoxLayout;
class QHBoxLayout;
class QStackedWidget;
QT_END_NAMESPACE

struct Word {
    std::string secretWord;
    int lives;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void startGame();
    void submitWord();
    void guessLetter();
    void guessWord();
    void playAgain();
    void exitGame();

private:
    // UI Components
    QStackedWidget *stackedWidget;

    // Setup Page
    QWidget *setupPage;
    QLineEdit *user1Edit;
    QLineEdit *user2Edit;
    QPushButton *startButton;

    // Word Input Page
    QWidget *wordInputPage;
    QLabel *currentPlayerLabel;
    QLineEdit *secretWordEdit;
    QSpinBox *livesSpinBox;
    QPushButton *submitWordButton;
    QLabel *wordInputInstructions;

    // Game Page
    QWidget *gamePage;
    QLabel *hangmanDisplay;
    QLabel *wordProgressLabel;
    QLabel *usedLettersLabel;
    QLabel *livesLabel;
    QLabel *currentGuesserLabel;
    QLineEdit *letterGuessEdit;
    QLineEdit *wordGuessEdit;
    QPushButton *guessLetterButton;
    QPushButton *guessWordButton;

    // End Page
    QWidget *endPage;
    QLabel *resultLabel;
    QLabel *scoreLabel;
    QPushButton *playAgainButton;
    QPushButton *exitButton;

    // Game Logic Variables
    std::string user1Name;
    std::string user2Name;
    int user1Score;
    int user2Score;
    int currentRound;
    std::string currentChooser;
    std::string currentGuesser;
    Word currentWord;
    std::vector<char> guessedLetters;
    std::vector<std::string> usedWords;
    int remainingLives;

    // Helper Methods
    void setupUI();
    void setupSetupPage();
    void setupWordInputPage();
    void setupGamePage();
    void setupEndPage();
    void toLowerCase(std::string &s);
    bool alreadyUsed(const std::string &word, const std::vector<std::string> &usedWords);
    void showProgress();
    void showUsedLetters();
    void drawHangman(int livesLeft, int totalLives);
    bool isWordGuessed();
    void revealRandomLetter();
    void startNewRound();
    void endRound(bool guesserWon);
    void updateGameDisplay();
    void resetGameState();
};

#endif // MAINWINDOW_H
